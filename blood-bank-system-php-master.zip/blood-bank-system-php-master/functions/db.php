<?php
		function db(){
			$conn=mysqli_connect("localhost","root","Aba4333250","ikthss");
			return $conn;

		}


?>